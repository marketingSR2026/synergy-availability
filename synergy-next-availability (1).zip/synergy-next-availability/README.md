# Synergy Next Availability

Cached "next available appointment" widget. Visitors only read Synergy's cache. They never cause a Jane request.

## Status of the data source (read first)
Jane has no open availability API or API keys, and its Acceptable Use Policy prohibits collecting data from its services with bots, crawlers or scrapers. This plugin therefore does not scrape Jane. Live collection is OFF until Jane gives written permission or an official feed.

- `Import provider` (default): availability is pushed in by an approved source (admin paste or authenticated REST push). Makes no outbound requests.
- `Jane provider`: stays disabled until `SYNAV_JANE_AUTHORIZED` and `SYNAV_JANE_FEED_URL` are defined in wp-config.php (approved feed, ETag conditional requests, 10 s timeout).

## Install
Upload the zip in Plugins > Add New > Upload, activate, open "Synergy Availability" in the admin menu.

## Shortcodes
- `[synergy_availability]` compact list (3 to 5 soonest)
- `[synergy_availability location="langley"]`, `service="physiotherapy"`, or both
- `[synergy_availability mode="full"]` full page for /appointments/

## REST
`GET /wp-json/synergy/v1/availability?location=&service=&date=today|tomorrow|YYYY-MM-DD&sort=soonest|location|duration&limit=`
Cache only. `Cache-Control: public, max-age=60, s-maxage=120`, ETag, 304 support.
`POST /wp-json/synergy/v1/ingest` and `GET /wp-json/synergy/v1/cron` need the secret token (header `X-Synergy-Token`).

## Scheduling
Every 10 min. WP-Cron by default. For reliability add a server cron (cPanel) hitting `/cron` with the token, and set `DISABLE_WP_CRON` true. Failures back off 10 > 20 > 40 min and the last good data keeps being served. Overlapping runs are locked. Unchanged data skips the database write.

## Raw slot format (feed or import)
```json
[{"location":"Langley","service":"Massage Therapy","treatment":"60 Minute RMT","practitioner":"Name",
  "duration":60,"datetime":"2026-10-01T14:30:00-07:00","booking_url":"https://synergyrehab.janeapp.com/..."}]
```
`date` + `time` may replace `datetime`. Booking URLs must start with https://synergyrehab.janeapp.com/ or the row is rejected. No patient data is stored.

## Time zone
America/Vancouver. BC adopted permanent daylight time (UTC-7 all year) after 2026-03-08. The server needs a current tz database. Feeds that include an explicit offset are safest.

## Tests
`php tests/test-normalizer.php` and `node tests/test-js.mjs`

## Not yet verified
Real Jane data, deep-link URL pattern per service/practitioner, location coordinates (nearest-location is not enabled), and a live WordPress install.
