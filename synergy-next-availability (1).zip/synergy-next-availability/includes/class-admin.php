<?php
class Synergy_Av_Admin {
	public static function init() {
		add_action( 'admin_menu', function () { add_menu_page( 'Synergy Availability', 'Synergy Availability', 'manage_options', 'synergy-availability', array( __CLASS__, 'page' ), 'dashicons-calendar-alt', 58 ); } );
		add_action( 'admin_post_synav_refresh', array( __CLASS__, 'refresh' ) );
		add_action( 'admin_post_synav_import', array( __CLASS__, 'import' ) );
		add_action( 'admin_post_synav_provider', array( __CLASS__, 'set_provider' ) );
	}
	private static function guard( $action ) {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Not allowed', 403 ); }
		check_admin_referer( $action );
	}
	private static function back( $msg ) { wp_safe_redirect( add_query_arg( 'synav_msg', rawurlencode( $msg ), admin_url( 'admin.php?page=synergy-availability' ) ) ); exit; }
	public static function refresh() { self::guard( 'synav_refresh' ); self::back( 'Refresh result: ' . Synergy_Av_Scheduler::run( true ) ); }
	public static function set_provider() {
		self::guard( 'synav_provider' );
		$p = isset( $_POST['provider'] ) && 'jane' === $_POST['provider'] ? 'jane' : 'import';
		update_option( 'synav_provider', $p, false ); self::back( 'Provider set to ' . $p );
	}
	public static function import() {
		self::guard( 'synav_import' );
		$json = isset( $_POST['json'] ) ? json_decode( wp_unslash( $_POST['json'] ), true ) : null; // validated below; never echoed raw
		if ( ! is_array( $json ) ) { self::back( 'Invalid JSON, nothing imported.' ); }
		list( $rows, $bad ) = Synergy_Av_Normalizer::bulk( $json, gmdate( 'c' ) );
		if ( isset( $_POST['test_only'] ) ) { self::back( sprintf( 'Test: %d valid, %d rejected (nothing saved).', count( $rows ), $bad ) ); }
		update_option( 'synav_import_raw', $json, false );
		self::back( 'Imported. Refresh result: ' . Synergy_Av_Scheduler::run( true, true ) );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) { return; }
		$s = Synergy_Av_Cache::status(); $rows = Synergy_Av_Cache::public_rows(); $p = Synergy_Av_Scheduler::provider(); $ps = $p->status();
		$age = $s['last_success'] ? ( time() - $s['last_success'] ) / 60 : null;
		$stale = null === $age || $age > 25;
		$health = 'error' === $s['state'] ? 'Error (serving last known data)' : ( $stale ? 'Stale' : 'Healthy' );
		$f = function ( $t ) { return $t ? esc_html( wp_date( 'g:i A', $t, new DateTimeZone( SYNAV_TZ ) ) ) : '-'; };
		$msg = isset( $_GET['synav_msg'] ) ? sanitize_text_field( wp_unslash( $_GET['synav_msg'] ) ) : '';
		$cron = rest_url( 'synergy/v1/cron' );
		?>
		<div class="wrap"><h1>Synergy Availability</h1>
		<?php if ( $msg ) : ?><div class="notice notice-info"><p><?php echo esc_html( $msg ); ?></p></div><?php endif; ?>
		<table class="widefat striped" style="max-width:640px"><tbody>
			<tr><th>Status</th><td><strong><?php echo esc_html( $health ); ?></strong></td></tr>
			<tr><th>Last success</th><td><?php echo $f( $s['last_success'] ); ?></td></tr>
			<tr><th>Next update</th><td><?php echo $f( max( $s['next_run'], 0 ) ?: (int) wp_next_scheduled( Synergy_Av_Scheduler::HOOK ) ); ?></td></tr>
			<tr><th>Appointments</th><td><?php echo (int) count( $rows ); ?></td></tr>
			<tr><th>Locations</th><td><?php echo (int) count( array_unique( wp_list_pluck( $rows, 'location_slug' ) ) ); ?></td></tr>
			<tr><th>Services</th><td><?php echo (int) count( array_unique( wp_list_pluck( $rows, 'service_slug' ) ) ); ?></td></tr>
			<tr><th>Rejected rows (last run)</th><td><?php echo (int) $s['rejected']; ?></td></tr>
			<tr><th>Provider</th><td><?php echo esc_html( $p->label() . ': ' . $ps['message'] ); ?></td></tr>
			<tr><th>WP-Cron</th><td><?php echo defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ? 'Disabled (using server cron)' : 'Enabled (needs traffic or a server cron)'; ?></td></tr>
		</tbody></table>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:12px 0"><?php wp_nonce_field( 'synav_refresh' ); ?><input type="hidden" name="action" value="synav_refresh"><button class="button button-primary">Refresh now</button></form>

		<h2>Provider</h2>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><?php wp_nonce_field( 'synav_provider' ); ?><input type="hidden" name="action" value="synav_provider">
			<select name="provider"><option value="import" <?php selected( $p->id(), 'import' ); ?>>Import / push</option><option value="jane" <?php selected( $p->id(), 'jane' ); ?>>Jane (approved feed only)</option></select> <button class="button">Save</button></form>

		<h2>Testing tools</h2>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><?php wp_nonce_field( 'synav_import' ); ?><input type="hidden" name="action" value="synav_import">
			<p>Paste a JSON array of slots (see README). "Validate only" saves nothing.</p>
			<textarea name="json" rows="6" class="large-text code"></textarea>
			<p><button class="button" name="test_only" value="1">Validate only</button> <button class="button button-secondary">Import</button></p></form>

		<h2>External cron (optional, more reliable than WP-Cron)</h2>
		<p>Server cron every 10 min: <code>*/10 * * * * curl -s -H "X-Synergy-Token: YOUR_TOKEN" <?php echo esc_html( $cron ); ?></code></p>
		<p>Token (keep private): <code><?php echo esc_html( Synergy_Av_Rest::token() ); ?></code></p>

		<h2>Recent errors</h2>
		<?php if ( empty( $s['errors'] ) ) : ?><p>None.</p><?php else : ?><ul><?php foreach ( $s['errors'] as $e ) : ?><li><?php echo esc_html( $e['t'] . ' - ' . $e['m'] ); ?></li><?php endforeach; ?></ul><?php endif; ?>
		</div>
		<?php
	}
}
