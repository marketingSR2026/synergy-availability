<?php
class Synergy_Av_Rest {
	public static function init() { add_action( 'rest_api_init', array( __CLASS__, 'routes' ) ); }

	public static function token() {
		$t = get_option( 'synav_token' );
		if ( ! $t ) { $t = wp_generate_password( 40, false ); update_option( 'synav_token', $t, false ); }
		return $t;
	}
	private static function token_ok( WP_REST_Request $r ) {
		$given = (string) ( $r->get_header( 'x-synergy-token' ) ?: $r->get_param( 'token' ) );
		return $given !== '' && hash_equals( self::token(), $given );
	}

	public static function routes() {
		register_rest_route( 'synergy/v1', '/availability', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'get' ), 'permission_callback' => '__return_true',
			'args' => array(
				'location' => array( 'sanitize_callback' => 'sanitize_title' ),
				'service'  => array( 'sanitize_callback' => 'sanitize_title' ),
				'date'     => array( 'sanitize_callback' => 'sanitize_text_field' ),
				'sort'     => array( 'sanitize_callback' => 'sanitize_key', 'validate_callback' => function ( $v ) { return in_array( $v, array( 'soonest', 'location', 'duration' ), true ); } ),
				'limit'    => array( 'sanitize_callback' => 'absint' ),
			),
		) );
		register_rest_route( 'synergy/v1', '/ingest', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'ingest' ), 'permission_callback' => function ( $r ) { return self::token_ok( $r ); } ) );
		register_rest_route( 'synergy/v1', '/cron', array( 'methods' => 'GET,POST', 'callback' => array( __CLASS__, 'cron' ), 'permission_callback' => function ( $r ) { return self::token_ok( $r ); } ) );
	}

	/** Cache-only. Never touches a provider. */
	public static function get( WP_REST_Request $r ) {
		$rows = Synergy_Av_Normalizer::filter( Synergy_Av_Cache::public_rows(), $r->get_params(), time() );
		$s    = Synergy_Av_Cache::status();
		$body = array(
			'updated_at' => $s['last_success'] ? gmdate( 'c', $s['last_success'] ) : null,
			'stale'      => ! $s['last_success'] || ( time() - $s['last_success'] ) > 1500,
			'count'      => count( $rows ),
			'locations'  => Synergy_Av_Cache::locations(),
			'items'      => $rows,
		);
		$etag = '"' . md5( wp_json_encode( array( get_option( 'synav_version' ), $r->get_params(), (int) floor( time() / 60 ) ) ) ) . '"'; // minute bucket: past slots roll off
		$res  = new WP_REST_Response( $body );
		$res->header( 'Cache-Control', 'public, max-age=60, s-maxage=120, stale-while-revalidate=300' );
		$res->header( 'ETag', $etag );
		if ( isset( $_SERVER['HTTP_IF_NONE_MATCH'] ) && trim( wp_unslash( $_SERVER['HTTP_IF_NONE_MATCH'] ) ) === $etag ) { $res->set_status( 304 ); $res->set_data( null ); }
		return $res;
	}

	/** Authorised push of raw slots from an approved source. Stored, then normalized by the normal refresh. */
	public static function ingest( WP_REST_Request $r ) {
		$data = $r->get_json_params();
		if ( ! is_array( $data ) || count( $data ) > 20000 ) { return new WP_REST_Response( array( 'error' => 'invalid body' ), 400 ); }
		update_option( 'synav_import_raw', $data, false );
		return array( 'result' => Synergy_Av_Scheduler::run( true, true ) );
	}
	public static function cron( WP_REST_Request $r ) { return array( 'result' => Synergy_Av_Scheduler::run( false ) ); }
}
