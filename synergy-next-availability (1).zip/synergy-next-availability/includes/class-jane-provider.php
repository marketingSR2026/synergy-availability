<?php
/**
 * JaneAvailabilityProvider
 *
 * Jane has no open availability API or API keys, and its Acceptable Use Policy prohibits automated
 * collection from its services. This class therefore does NOT scrape anything. It stays disabled until
 * Synergy has WRITTEN permission or an official feed from Jane. To activate:
 *   1. Obtain the approved endpoint/feed from Jane.
 *   2. define( 'SYNAV_JANE_AUTHORIZED', true ); and define( 'SYNAV_JANE_FEED_URL', 'https://...' ); in wp-config.php
 *   3. Feed must return a JSON array of raw slots (README). Conditional requests (ETag) are used.
 */
class Synergy_Av_Jane_Provider implements Synergy_Av_Provider_Interface {
	public function id() { return 'jane'; }
	public function label() { return 'Jane (approved feed only)'; }
	private function authorized() { return defined( 'SYNAV_JANE_AUTHORIZED' ) && SYNAV_JANE_AUTHORIZED === true && defined( 'SYNAV_JANE_FEED_URL' ); }
	public function status() {
		return $this->authorized()
			? array( 'ready' => true, 'message' => 'Approved feed configured' )
			: array( 'ready' => false, 'message' => 'Not activated: needs written permission / official feed from Jane' );
	}
	public function fetch() {
		if ( ! $this->authorized() ) { return new WP_Error( 'synav_not_authorized', 'Jane provider is not authorized.' ); }
		$url = esc_url_raw( SYNAV_JANE_FEED_URL );
		$hdr = array( 'Accept' => 'application/json', 'User-Agent' => 'SynergyNextAvailability/' . SYNAV_VERSION );
		$etag = get_option( 'synav_feed_etag' );
		if ( $etag ) { $hdr['If-None-Match'] = $etag; }
		$res = wp_remote_get( $url, array( 'timeout' => 10, 'redirection' => 2, 'headers' => $hdr ) );
		if ( is_wp_error( $res ) ) { return $res; }
		$code = wp_remote_retrieve_response_code( $res );
		if ( 304 === $code ) { return get_option( 'synav_last_raw', array() ); }
		if ( 429 === $code || $code >= 500 ) { return new WP_Error( 'synav_upstream', "Upstream HTTP $code" ); }
		if ( 200 !== $code ) { return new WP_Error( 'synav_http', "Unexpected HTTP $code" ); }
		$data = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( ! is_array( $data ) ) { return new WP_Error( 'synav_malformed', 'Malformed JSON from feed' ); }
		$e = wp_remote_retrieve_header( $res, 'etag' );
		if ( $e ) { update_option( 'synav_feed_etag', $e, false ); }
		update_option( 'synav_last_raw', $data, false );
		return $data;
	}
}
