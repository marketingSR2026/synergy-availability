<?php
class Synergy_Av_Scheduler {
	const HOOK = 'synav_refresh'; const BASE = 600; const MAX = 2400;

	public static function init() {
		add_filter( 'cron_schedules', function ( $s ) { $s['synav_10min'] = array( 'interval' => 600, 'display' => 'Every 10 minutes' ); return $s; } );
		add_action( self::HOOK, array( __CLASS__, 'run' ) );
		if ( ! wp_next_scheduled( self::HOOK ) ) { wp_schedule_event( time() + 60, 'synav_10min', self::HOOK ); }
	}
	public static function activate() { if ( ! wp_next_scheduled( self::HOOK ) ) { wp_schedule_event( time() + 60, 'synav_10min', self::HOOK ); } }
	public static function deactivate() { wp_clear_scheduled_hook( self::HOOK ); }

	public static function provider() {
		$id = get_option( 'synav_provider', 'import' );
		return 'jane' === $id ? new Synergy_Av_Jane_Provider() : new Synergy_Av_Import_Provider();
	}

	/** One refresh. $force skips the backoff gate (manual button). Never called by visitors. */
	public static function run( $force = false, $from_push = false ) {
		// Import provider: data only changes when the collector pushes. Cron/manual runs must not look like a fresh success.
		if ( 'import' === self::provider()->id() && ! $from_push ) { return 'idle'; }
		$s = Synergy_Av_Cache::status();
		if ( ! $force && $s['next_run'] && time() < $s['next_run'] ) { return 'backoff'; }
		if ( get_transient( 'synav_lock' ) ) { return 'locked'; }
		set_transient( 'synav_lock', 1, 120 ); // dedupe overlapping runs (cron + external cron)

		$s['last_attempt'] = time();
		$raw = self::provider()->fetch();
		if ( is_wp_error( $raw ) ) {
			$s['fails']++;
			$s['state']    = 'error';
			$s['next_run'] = time() + min( self::MAX, self::BASE * ( 2 ** ( $s['fails'] - 1 ) ) ); // 10 -> 20 -> 40 min
			Synergy_Av_Cache::save_status( $s );
			Synergy_Av_Cache::log_error( $raw->get_error_message() );
			delete_transient( 'synav_lock' );
			return 'error'; // last known data keeps being served
		}
		list( $rows, $bad ) = Synergy_Av_Normalizer::bulk( $raw, gmdate( 'c' ) );
		$rows = Synergy_Av_Normalizer::drop_past( $rows, time() );
		if ( ! $rows && $raw ) { // every row malformed: treat as failure, keep last good data
			$s['fails']++; $s['state'] = 'error'; $s['rejected'] = $bad;
			$s['next_run'] = time() + min( self::MAX, self::BASE * ( 2 ** ( $s['fails'] - 1 ) ) );
			Synergy_Av_Cache::save_status( $s );
			Synergy_Av_Cache::log_error( 'All rows rejected as malformed' );
			delete_transient( 'synav_lock' );
			return 'error';
		}
		list( $changed, $hash ) = Synergy_Av_Cache::store( $rows );
		$s['hash'] = $hash; $s['rejected'] = $bad; $s['fails'] = 0; $s['state'] = 'ok';
		$s['last_success'] = time(); $s['next_run'] = time() + self::BASE;
		if ( $changed ) { update_option( 'synav_version', time(), false ); }
		Synergy_Av_Cache::save_status( $s );
		delete_transient( 'synav_lock' );
		return $changed ? 'updated' : 'unchanged';
	}
}
