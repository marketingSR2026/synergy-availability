<?php
class Synergy_Av_Cache {
	const DATA = 'synav_data'; const STATUS = 'synav_status';

	public static function rows() { $d = get_option( self::DATA, array() ); return is_array( $d ) ? $d : array(); }
	public static function status() {
		return wp_parse_args( get_option( self::STATUS, array() ), array(
			'last_success' => 0, 'last_attempt' => 0, 'next_run' => 0, 'fails' => 0, 'hash' => '', 'rejected' => 0, 'errors' => array(), 'state' => 'waiting',
		) );
	}
	public static function save_status( $s ) { update_option( self::STATUS, $s, false ); }

	/** Replace dataset. Skips the DB write when nothing changed. Returns true if data changed. */
	public static function store( $rows ) {
		$hash = md5( wp_json_encode( array_map( function ( $r ) { return $r['id']; }, $rows ) ) );
		$s    = self::status();
		$changed = ( $hash !== $s['hash'] );
		if ( $changed ) { update_option( self::DATA, $rows, false ); }
		return array( $changed, $hash );
	}
	public static function log_error( $msg ) {
		$s = self::status();
		array_unshift( $s['errors'], array( 't' => gmdate( 'c' ), 'm' => substr( wp_strip_all_tags( $msg ), 0, 200 ) ) );
		$s['errors'] = array_slice( $s['errors'], 0, 10 ); // small log, no patient data
		self::save_status( $s );
	}
	/** Rows for public output: future only. Stale data is still served (last known). */
	public static function public_rows() {
		return Synergy_Av_Normalizer::drop_past( self::rows(), time() );
	}
	public static function locations() {
		static $c; if ( $c ) { return $c; }
		$f = SYNAV_DIR . 'data/locations.json';
		$c = file_exists( $f ) ? json_decode( file_get_contents( $f ), true ) : array();
		return is_array( $c ) ? $c : array();
	}
}
