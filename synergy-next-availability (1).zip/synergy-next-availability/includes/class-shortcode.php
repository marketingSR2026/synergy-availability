<?php
class Synergy_Av_Shortcode {
	public static function init() { add_shortcode( 'synergy_availability', array( __CLASS__, 'render' ) ); }

	public static function render( $atts ) {
		$a = shortcode_atts( array( 'location' => '', 'service' => '', 'mode' => 'compact', 'limit' => '5', 'full_url' => '/appointments/' ), $atts, 'synergy_availability' );
		$mode = in_array( $a['mode'], array( 'compact', 'full' ), true ) ? $a['mode'] : 'compact';
		wp_enqueue_style( 'synav', SYNAV_URL . 'assets/css/availability.css', array(), SYNAV_VERSION );
		wp_enqueue_script( 'synav', SYNAV_URL . 'assets/js/availability.js', array(), SYNAV_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
		$cfg = array(
			'mode' => $mode, 'location' => sanitize_title( $a['location'] ), 'service' => sanitize_title( $a['service'] ),
			'limit' => max( 1, min( 8, (int) $a['limit'] ) ), 'api' => esc_url_raw( rest_url( 'synergy/v1/availability' ) ),
			'fullUrl' => esc_url_raw( home_url( $a['full_url'] ) ), 'tz' => SYNAV_TZ,
		);
		ob_start();
		include SYNAV_DIR . 'templates/' . $mode . '.php';
		return ob_get_clean();
	}
}
