<?php
/** Pure PHP (no WordPress calls) so it can be unit tested. */
class Synergy_Av_Normalizer {

	public static function slug( $s ) {
		$s = strtolower( trim( (string) $s ) );
		$s = preg_replace( '/[^a-z0-9]+/', '-', $s );
		return trim( $s, '-' );
	}

	/** Validate and normalize one raw slot. Returns array or null if invalid. */
	public static function slot( $raw, $checked_at, $ttl = 1800 ) {
		if ( ! is_array( $raw ) ) { return null; }
		$dt = isset( $raw['datetime'] ) ? $raw['datetime'] : null;
		if ( ! $dt && ! empty( $raw['date'] ) && ! empty( $raw['time'] ) ) {
			$dt = $raw['date'] . 'T' . $raw['time'] . ':00';
		}
		if ( ! $dt ) { return null; }
		try {
			$tz = new DateTimeZone( 'America/Vancouver' );
			$d  = new DateTimeImmutable( (string) $dt, $tz ); // offset in string wins; otherwise Vancouver time
			$d  = $d->setTimezone( $tz );
		} catch ( Exception $e ) { return null; }

		$location = trim( (string) ( $raw['location'] ?? '' ) );
		$service  = trim( (string) ( $raw['service'] ?? '' ) );
		$url      = (string) ( $raw['booking_url'] ?? '' );
		if ( $location === '' || $service === '' ) { return null; }
		if ( ! preg_match( '#^https://synergyrehab\.janeapp\.com/#i', $url ) ) { return null; } // bookings only go to Jane
		$duration = (int) ( $raw['duration'] ?? 0 );
		if ( $duration < 5 || $duration > 240 ) { $duration = 0; }

		$row = array(
			'location'      => $location,
			'location_slug' => self::slug( $raw['location_slug'] ?? $location ),
			'service'       => $service,
			'service_slug'  => self::slug( $raw['service_slug'] ?? $service ),
			'treatment'     => trim( (string) ( $raw['treatment'] ?? '' ) ),
			'practitioner'  => trim( (string) ( $raw['practitioner'] ?? '' ) ),
			'date'          => $d->format( 'Y-m-d' ),
			'time'          => $d->format( 'H:i' ),
			'datetime'      => $d->format( 'c' ),
			'duration'      => $duration,
			'booking_url'   => $url,
			'source'        => preg_replace( '/[^a-z0-9_-]/i', '', (string) ( $raw['source'] ?? 'import' ) ),
			'checked_at'    => $checked_at,
			'expires_at'    => gmdate( 'c', strtotime( $checked_at ) + (int) $ttl ),
			'status'        => 'available',
		);
		$row['id'] = substr( sha1( $row['location_slug'] . '|' . $row['service_slug'] . '|' . $row['treatment'] . '|' . $row['practitioner'] . '|' . $row['datetime'] ), 0, 16 );
		return $row;
	}

	/** Normalize a list, drop invalid, dedupe by id, sort soonest. Returns [rows, rejected_count]. */
	public static function bulk( $raws, $checked_at, $ttl = 1800 ) {
		$out = array(); $bad = 0;
		if ( ! is_array( $raws ) ) { return array( array(), 1 ); }
		foreach ( $raws as $r ) {
			$n = self::slot( $r, $checked_at, $ttl );
			if ( ! $n ) { $bad++; continue; }
			$out[ $n['id'] ] = $n;
		}
		$out = array_values( $out );
		usort( $out, function ( $a, $b ) { return strcmp( $a['datetime'], $b['datetime'] ) ?: strcmp( $a['location_slug'], $b['location_slug'] ); } );
		return array( $out, $bad );
	}

	/** Drop slots already in the past. */
	public static function drop_past( $rows, $now_ts ) {
		return array_values( array_filter( $rows, function ( $r ) use ( $now_ts ) { return strtotime( $r['datetime'] ) >= $now_ts; } ) );
	}

	/** Filter used by REST (same logic as JS). */
	public static function filter( $rows, $q, $now_ts ) {
		$tz    = new DateTimeZone( 'America/Vancouver' );
		$today = ( new DateTimeImmutable( '@' . $now_ts ) )->setTimezone( $tz )->format( 'Y-m-d' );
		$date  = isset( $q['date'] ) ? (string) $q['date'] : '';
		if ( $date === 'today' ) { $date = $today; }
		elseif ( $date === 'tomorrow' ) { $date = ( new DateTimeImmutable( $today, $tz ) )->modify( '+1 day' )->format( 'Y-m-d' ); }
		elseif ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) { $date = ''; }
		$loc = self::slug( $q['location'] ?? '' ); $svc = self::slug( $q['service'] ?? '' );
		$out = array_values( array_filter( $rows, function ( $r ) use ( $loc, $svc, $date ) {
			return ( ! $loc || $r['location_slug'] === $loc ) && ( ! $svc || $r['service_slug'] === $svc ) && ( ! $date || $r['date'] === $date );
		} ) );
		$sort = $q['sort'] ?? 'soonest';
		if ( $sort === 'location' ) { usort( $out, function ( $a, $b ) { return strcmp( $a['location'], $b['location'] ) ?: strcmp( $a['datetime'], $b['datetime'] ); } ); }
		elseif ( $sort === 'duration' ) { usort( $out, function ( $a, $b ) { return $a['duration'] <=> $b['duration'] ?: strcmp( $a['datetime'], $b['datetime'] ); } ); }
		$limit = isset( $q['limit'] ) ? max( 1, min( 500, (int) $q['limit'] ) ) : 0;
		return $limit ? array_slice( $out, 0, $limit ) : $out;
	}
}
