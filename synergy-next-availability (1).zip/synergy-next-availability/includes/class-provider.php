<?php
/**
 * Replaceable availability source. fetch() returns raw slot arrays (see README) or WP_Error.
 * Providers must NEVER be called from a visitor request. Only the scheduler/admin/ingest may call them.
 */
interface Synergy_Av_Provider_Interface {
	public function id();
	public function label();
	/** @return array|WP_Error list of raw slots */
	public function fetch();
	/** @return array [ 'ready' => bool, 'message' => string ] */
	public function status();
}

/** Reads availability pushed in via the authenticated ingest endpoint or the admin JSON import. No outbound requests. */
class Synergy_Av_Import_Provider implements Synergy_Av_Provider_Interface {
	public function id() { return 'import'; }
	public function label() { return 'Import / push (no outbound requests)'; }
	public function fetch() {
		$raw = get_option( 'synav_import_raw', array() );
		return is_array( $raw ) ? $raw : array();
	}
	public function status() {
		$n = count( (array) get_option( 'synav_import_raw', array() ) );
		return array( 'ready' => $n > 0, 'message' => $n ? "$n slots in last import" : 'Waiting for an import or push' );
	}
}
