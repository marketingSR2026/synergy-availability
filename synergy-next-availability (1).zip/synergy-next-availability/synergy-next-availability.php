<?php
/**
 * Plugin Name: Synergy Next Availability
 * Description: Cached "Next Available Appointment" widget for Synergy Rehab. Visitors never trigger Jane requests; all filtering uses cached data.
 * Version: 1.0.0
 * Requires PHP: 7.4
 * Author: Synergy Rehab
 * Text Domain: synergy-availability
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'SYNAV_VERSION', '1.0.0' );
define( 'SYNAV_DIR', plugin_dir_path( __FILE__ ) );
define( 'SYNAV_URL', plugin_dir_url( __FILE__ ) );
define( 'SYNAV_TZ', 'America/Vancouver' );

require_once SYNAV_DIR . 'includes/class-normalizer.php';
require_once SYNAV_DIR . 'includes/class-provider.php';
require_once SYNAV_DIR . 'includes/class-jane-provider.php';
require_once SYNAV_DIR . 'includes/class-cache.php';
require_once SYNAV_DIR . 'includes/class-scheduler.php';
require_once SYNAV_DIR . 'includes/class-rest-api.php';
require_once SYNAV_DIR . 'includes/class-admin.php';
require_once SYNAV_DIR . 'includes/class-shortcode.php';

add_action( 'plugins_loaded', function () {
	Synergy_Av_Scheduler::init();
	Synergy_Av_Rest::init();
	Synergy_Av_Admin::init();
	Synergy_Av_Shortcode::init();
} );

register_activation_hook( __FILE__, array( 'Synergy_Av_Scheduler', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Synergy_Av_Scheduler', 'deactivate' ) );
