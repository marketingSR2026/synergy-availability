<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<section class="synav synav--full" data-synav="<?php echo esc_attr( wp_json_encode( $cfg ) ); ?>" aria-labelledby="synav-h-full">
	<h2 class="synav__title" id="synav-h-full"><?php esc_html_e( 'Available appointments', 'synergy-availability' ); ?></h2>
	<form class="synav__filters synav__filters--full" onsubmit="return false">
		<label class="synav__label"><span><?php esc_html_e( 'Location', 'synergy-availability' ); ?></span><select data-f="location"><option value=""><?php esc_html_e( 'All locations', 'synergy-availability' ); ?></option></select></label>
		<label class="synav__label"><span><?php esc_html_e( 'Service', 'synergy-availability' ); ?></span><select data-f="service"><option value=""><?php esc_html_e( 'All services', 'synergy-availability' ); ?></option></select></label>
		<fieldset class="synav__chips"><legend><?php esc_html_e( 'Day', 'synergy-availability' ); ?></legend>
			<button type="button" data-day="" aria-pressed="true"><?php esc_html_e( 'Any', 'synergy-availability' ); ?></button>
			<button type="button" data-day="today" aria-pressed="false"><?php esc_html_e( 'Today', 'synergy-availability' ); ?></button>
			<button type="button" data-day="tomorrow" aria-pressed="false"><?php esc_html_e( 'Tomorrow', 'synergy-availability' ); ?></button></fieldset>
		<details class="synav__more-filters"><summary><?php esc_html_e( 'More filters', 'synergy-availability' ); ?></summary><div class="synav__filters">
		<label class="synav__label"><span><?php esc_html_e( 'Time', 'synergy-availability' ); ?></span><select data-f="time">
			<option value=""><?php esc_html_e( 'Any time', 'synergy-availability' ); ?></option><option value="am"><?php esc_html_e( 'Morning (before 12)', 'synergy-availability' ); ?></option><option value="pm"><?php esc_html_e( 'Afternoon (12 to 5)', 'synergy-availability' ); ?></option><option value="eve"><?php esc_html_e( 'Evening (after 5)', 'synergy-availability' ); ?></option></select></label>
		<label class="synav__label"><span><?php esc_html_e( 'Duration', 'synergy-availability' ); ?></span><select data-f="duration"><option value=""><?php esc_html_e( 'Any length', 'synergy-availability' ); ?></option></select></label>
		<label class="synav__label"><span><?php esc_html_e( 'Practitioner', 'synergy-availability' ); ?></span><select data-f="practitioner"><option value=""><?php esc_html_e( 'Any practitioner', 'synergy-availability' ); ?></option></select></label>
		<label class="synav__label"><span><?php esc_html_e( 'Sort', 'synergy-availability' ); ?></span><select data-f="sort"><option value="soonest"><?php esc_html_e( 'Soonest', 'synergy-availability' ); ?></option><option value="location"><?php esc_html_e( 'Location', 'synergy-availability' ); ?></option><option value="duration"><?php esc_html_e( 'Duration', 'synergy-availability' ); ?></option></select></label>
		</div></details>
	</form>
	<p class="synav__updated" data-updated></p>
	<div class="synav__list" data-list aria-live="polite"><p class="synav__msg"><?php esc_html_e( 'Loading appointments…', 'synergy-availability' ); ?></p></div>
	<button type="button" class="synav__btn synav__btn--ghost" data-more hidden><?php esc_html_e( 'Show more', 'synergy-availability' ); ?></button>
</section>
