<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<section class="synav synav--compact" data-synav="<?php echo esc_attr( wp_json_encode( $cfg ) ); ?>" aria-labelledby="synav-h-<?php echo esc_attr( $cfg['mode'] ); ?>">
	<h2 class="synav__title" id="synav-h-<?php echo esc_attr( $cfg['mode'] ); ?>"><?php esc_html_e( 'Next available appointments', 'synergy-availability' ); ?></h2>
	<p class="synav__sub"><?php esc_html_e( 'Find an appointment today.', 'synergy-availability' ); ?></p>
	<div class="synav__filters">
		<label class="synav__label"><span class="synav__sr"><?php esc_html_e( 'Service', 'synergy-availability' ); ?></span><select data-f="service"><option value=""><?php esc_html_e( 'All services', 'synergy-availability' ); ?></option></select></label>
		<label class="synav__label"><span class="synav__sr"><?php esc_html_e( 'Location', 'synergy-availability' ); ?></span><select data-f="location"><option value=""><?php esc_html_e( 'All locations', 'synergy-availability' ); ?></option></select></label>
	</div>
	<div class="synav__list" data-list aria-live="polite"><p class="synav__msg"><?php esc_html_e( 'Loading appointments…', 'synergy-availability' ); ?></p></div>
	<p class="synav__updated" data-updated></p>
	<a class="synav__more" href="<?php echo esc_url( $cfg['fullUrl'] ); ?>"><?php esc_html_e( 'View all available appointments', 'synergy-availability' ); ?> &rarr;</a>
	<noscript><p><?php esc_html_e( 'Please enable JavaScript to see live availability, or book at synergyrehab.janeapp.com.', 'synergy-availability' ); ?></p></noscript>
</section>
