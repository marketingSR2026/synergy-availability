(function () {
	'use strict';
	var JANE = /^https:\/\/synergyrehab\.janeapp\.com\//i;
	var STALE_MIN = 25;

	function el(t, c, txt) { var e = document.createElement(t); if (c) e.className = c; if (txt != null) e.textContent = txt; return e; }
	function ymd(d, tz) { return new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(d); }
	function fmtTime(iso, tz) { return new Intl.DateTimeFormat('en-CA', { timeZone: tz, hour: 'numeric', minute: '2-digit', hour12: true }).format(new Date(iso)).replace(/\./g, '').replace(' ', ' ').toUpperCase(); }
	function fmtDay(dateStr, today, tomorrow, tz) {
		if (dateStr === today) return 'Today';
		if (dateStr === tomorrow) return 'Tomorrow';
		return new Intl.DateTimeFormat('en-CA', { timeZone: tz, weekday: 'short', month: 'short', day: 'numeric' }).format(new Date(dateStr + 'T12:00:00'));
	}
	function ago(ts) { var m = Math.max(0, Math.round((Date.now() - ts) / 60000)); return m < 1 ? 'just now' : m === 1 ? '1 minute ago' : m < 90 ? m + ' minutes ago' : Math.round(m / 60) + ' hours ago'; }
	function uniq(items, key, label) { var m = {}; items.forEach(function (i) { m[i[key]] = i[label || key]; }); return Object.keys(m).map(function (k) { return [k, m[k]]; }).sort(function (a, b) { return String(a[1]).localeCompare(String(b[1]), undefined, { numeric: true }); }); }
	function fill(sel, pairs, keep) {
		var cur = keep || sel.value; while (sel.options.length > 1) sel.remove(1);
		pairs.forEach(function (p) { var o = el('option', '', p[1]); o.value = p[0]; sel.appendChild(o); });
		sel.value = cur; if (sel.value !== cur) sel.value = '';
	}

	function init(root) {
		var cfg = JSON.parse(root.getAttribute('data-synav')), tz = cfg.tz || 'America/Vancouver';
		var list = root.querySelector('[data-list]'), upd = root.querySelector('[data-updated]'), moreBtn = root.querySelector('[data-more]');
		var full = cfg.mode === 'full', state = { day: '', shown: 20 }, data = null;
		var f = {}; [].forEach.call(root.querySelectorAll('[data-f]'), function (s) { f[s.getAttribute('data-f')] = s; });

		function pass(i, skip) {
			var now = new Date(), today = ymd(now, tz), tmr = ymd(new Date(now.getTime() + 864e5), tz);
			if (cfg.location && i.location_slug !== cfg.location) return false;
			if (cfg.service && i.service_slug !== cfg.service) return false;
			if (skip !== 'location' && f.location && f.location.value && i.location_slug !== f.location.value) return false;
			if (skip !== 'service' && f.service && f.service.value && i.service_slug !== f.service.value) return false;
			if (skip !== 'practitioner' && f.practitioner && f.practitioner.value && i.practitioner !== f.practitioner.value) return false;
			if (skip !== 'duration' && f.duration && f.duration.value && String(i.duration) !== f.duration.value) return false;
			if (state.day === 'today' && i.date !== today) return false;
			if (state.day === 'tomorrow' && i.date !== tmr) return false;
			if (f.time && f.time.value) { var h = parseInt(i.time.slice(0, 2), 10); var b = h < 12 ? 'am' : h < 17 ? 'pm' : 'eve'; if (b !== f.time.value) return false; }
			return new Date(i.datetime).getTime() >= Date.now();
		}

		function renderMsg(text, sub, link) {
			list.textContent = ''; var p = el('div', 'synav__msg'); p.appendChild(el('strong', '', text)); if (sub) p.appendChild(el('span', '', sub));
			if (link) { var a = el('a', '', link[0]); a.href = link[1]; p.appendChild(a); } list.appendChild(p);
		}

		function render() {
			if (!data) return;
			var now = new Date(), today = ymd(now, tz), tmr = ymd(new Date(now.getTime() + 864e5), tz);
			var rows = data.items.filter(function (i) { return pass(i); });
			var sort = f.sort ? f.sort.value : 'soonest';
			if (sort === 'location') rows.sort(function (a, b) { return a.location.localeCompare(b.location) || a.datetime.localeCompare(b.datetime); });
			else if (sort === 'duration') rows.sort(function (a, b) { return (a.duration - b.duration) || a.datetime.localeCompare(b.datetime); });
			else rows.sort(function (a, b) { return new Date(a.datetime) - new Date(b.datetime); });

			var uAt = data.updated_at ? Date.parse(data.updated_at) : 0;
			var stale = !uAt || (Date.now() - uAt) / 60000 > STALE_MIN;
			upd.textContent = uAt ? (stale ? 'Availability was last updated ' + ago(uAt) + '. Confirm availability when booking.' : 'Availability updated ' + ago(uAt) + '.') : '';
			upd.classList.toggle('is-stale', stale);

			if (!rows.length) {
				var anyFilters = (f.location && f.location.value) || (f.service && f.service.value) || state.day || (f.time && f.time.value) || (f.duration && f.duration.value) || (f.practitioner && f.practitioner.value);
				var msg = state.day === 'today' ? 'No appointments found today.' : 'No appointments match.';
				var hint = state.day === 'today' ? 'Try tomorrow or another nearby Synergy location.' : (anyFilters ? 'Try a different day, service or location.' : 'Please check back soon or book directly in Jane.');
				renderMsg(msg, hint, ['Book on Jane', 'https://synergyrehab.janeapp.com/']); if (moreBtn) moreBtn.hidden = true; return;
			}
			var cap = full ? state.shown : cfg.limit, frag = document.createDocumentFragment();
			rows.slice(0, cap).forEach(function (i) {
				var c = el('article', 'synav__card'), t = el('div', 'synav__time');
				t.appendChild(el('span', 'synav__day', fmtDay(i.date, today, tmr, tz))); t.appendChild(el('span', 'synav__clock', fmtTime(i.datetime, tz)));
				var m = el('div', 'synav__meta'); m.appendChild(el('span', 'synav__svc', i.service));
				m.appendChild(el('span', 'synav__loc', i.location + (i.duration ? ' · ' + i.duration + ' min' : '')));
				if (full && i.practitioner) m.appendChild(el('span', 'synav__prac', i.practitioner));
				c.appendChild(t); c.appendChild(m);
				if (JANE.test(i.booking_url)) { var a = el('a', 'synav__btn', 'Book now'); a.href = i.booking_url; a.rel = 'noopener'; a.setAttribute('aria-label', 'Book ' + i.service + ' at ' + i.location + ', ' + fmtDay(i.date, today, tmr, tz) + ' ' + fmtTime(i.datetime, tz)); c.appendChild(a); }
				frag.appendChild(c);
			});
			list.textContent = ''; list.appendChild(frag);
			if (moreBtn) moreBtn.hidden = rows.length <= cap;
		}

		function options() {
			var items = data.items.filter(function (i) { return (!cfg.location || i.location_slug === cfg.location) && (!cfg.service || i.service_slug === cfg.service); });
			if (f.service) fill(f.service, uniq(items, 'service_slug', 'service'));
			if (f.location) fill(f.location, uniq(items, 'location_slug', 'location'));
			if (f.duration) fill(f.duration, uniq(items.filter(function (i) { return i.duration; }), 'duration').map(function (p) { return [p[0], p[0] + ' min']; }));
			if (f.practitioner) fill(f.practitioner, uniq(items.filter(function (i) { return i.practitioner; }), 'practitioner'));
			if (cfg.location && f.location) f.location.closest('label').hidden = true;
			if (cfg.service && f.service) f.service.closest('label').hidden = true;
		}

		Object.keys(f).forEach(function (k) { f[k].addEventListener('change', function () { state.shown = 20; render(); }); });
		[].forEach.call(root.querySelectorAll('[data-day]'), function (b) { b.addEventListener('click', function () { state.day = b.getAttribute('data-day'); [].forEach.call(root.querySelectorAll('[data-day]'), function (x) { x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); }); state.shown = 20; render(); }); });
		if (moreBtn) moreBtn.addEventListener('click', function () { state.shown += 20; render(); });

		// ONE request to the Synergy cache (never Jane). Browser/CDN caching via ETag.
		fetch(cfg.api).then(function (r) { if (!r.ok) throw 0; return r.json(); }).then(function (j) { data = j; options(); render(); })
			.catch(function () { renderMsg('Live availability is unavailable right now.', 'You can still book directly in Jane.', ['Book on Jane', 'https://synergyrehab.janeapp.com/']); });
		setInterval(render, 60000); // re-evaluate locally (rolls past slots off); no network
	}
	[].forEach.call(document.querySelectorAll('[data-synav]'), init);
})();
